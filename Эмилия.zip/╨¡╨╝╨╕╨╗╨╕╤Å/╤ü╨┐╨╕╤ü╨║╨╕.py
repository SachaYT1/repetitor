a = [1, 2, 3]
print(len(a))

print(a[1])

b = [4, 5, 6]

c = a + b
print(c)

b.append(3)
print(b.pop())


print(b)
print(c[::-1])