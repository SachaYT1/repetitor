

a = '1!2!3!4!5!6'
print(a.split('!'))

b = a.split('!')
print(''.join(b))